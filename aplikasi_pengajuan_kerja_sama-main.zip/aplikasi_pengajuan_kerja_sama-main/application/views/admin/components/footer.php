<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js">
    </script>
    <script src="<?= base_url(); ?>assets/js/scripts.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js"></script>
    <script src="<?=base_url('assets/js/chartjs-plugin-datalabels/chartjs-plugin-datalabels.js')?>"></script>
    <script src="<?=base_url('assets/jquery/jquery.min.js')?>"></script>
    
    <script src="<?= base_url(); ?>assets/assets/demo/chart.js"></script>
    
    <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest"></script>
    <script src="<?= base_url(); ?>assets/js/datatables-simple-demo.js"></script>
    