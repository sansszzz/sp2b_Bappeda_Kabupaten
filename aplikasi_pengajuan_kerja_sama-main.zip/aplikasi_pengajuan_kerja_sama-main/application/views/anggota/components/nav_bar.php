<nav class="sb-topnav navbar navbar-expand navbar-dark bg-secondary">
    <!-- Navbar Brand-->
    <a class="navbar-brand ps-3" href="<?= base_url();?>Dashboard/dashboard_anggota">
        <img src="<?= base_url() ?>assets/img/uigm.png" width="80px" alt=""></a>
    <!-- Sidebar Toggle-->
    <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i
            class="fas fa-bars"></i></button>


</nav>