<meta charset="utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
<meta name="description" content="" />
<meta name="author" content="" />
<title>BKPPU - UIGM</title>
<link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
<link href="<?= base_url() ?>assets/css/styles.css" rel="stylesheet" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js" crossorigin="anonymous"></script>
<script src="<?= base_url() ?>node_modules/sweetalert/dist/sweetalert.min.js"></script>
<script>const BASE_URL='<?= base_url(); ?>'; </script>
<link rel="icon"href="<?= base_url() ?>assets/img/logo.png" />
